const renderRegister = (req, res) => {
  res.render('register');
};

module.exports = {
  renderRegister
};
